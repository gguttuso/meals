package us.mattgreen;

// enum advantage = they check to prevent mistakes
public enum MealType {
    BREAKFAST("Breakfast"), DESSERT("Dessert"), DINNER("Dinner"), LUNCH("Lunch");

    private String meal;

    MealType(String meal) {
        this.meal = meal;
    }

    public String getMeal() {
        return meal;
    }
}
